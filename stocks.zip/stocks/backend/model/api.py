import os
import numpy as np
import pickle
import tensorflow as tf
import pandas as pd
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin

app = Flask(__name__)
CORS(app)

# Configuration for database and secret key
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database and login manager
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# --------------------------
# User Model for Login/Signup
# --------------------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

# Create DB tables if not exist
with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --------------------------
# Existing App Functionality
# --------------------------

# Allowed stock models (all lowercase)
ALLOWED_STOCKS = [
    "zomato", "wiproooo", "tata", "tata motors",
    "kalamandir", "hdfclife", "ambuja cement"
]

# Load preprocessed data scalers
scalers = {}
try:
    with open("scalers.pkl", "rb") as f:
        scalers = pickle.load(f)
    print("✅ Scalers loaded successfully")
except Exception as e:
    print(f"❌ Error loading scalers.pkl: {e}")

# Load trained models
models = {}
for stock in ALLOWED_STOCKS:
    model_path = f"{stock}_model.h5"
    if os.path.exists(model_path):
        try:
            models[stock] = tf.keras.models.load_model(model_path)
            print(f"✅ Loaded model for {stock}")
        except Exception as e:
            print(f"❌ Error loading {stock}_model.h5: {e}")
    else:
        print(f"⚠️ Model file '{model_path}' not found!")

# Dataset path for CSV files
DATASET_PATH = r"C:\Users\Kalyan Chakravarthi\Downloads\stocks\backend\static\datasets"

# Home Route: Protected home page listing products
@app.route('/')
@login_required
def home():
    return render_template('home.html', stocks=ALLOWED_STOCKS)

# Individual Product Page (protected)
@app.route('/product/<stock>')
@login_required
def product(stock):
    stock = stock.lower()
    if stock not in ALLOWED_STOCKS:
        return redirect(url_for('home'))
    
    file_path = os.path.join(DATASET_PATH, f"{stock}.csv")
    
    if not os.path.exists(file_path):
        print(f"Dataset file not found for {stock} at {file_path}")
        ohlc_data = {"open": "--", "high": "--", "low": "--", "close": "--"}
        chart_data = []
        features_data = None
        recommendation = "N/A"
    else:
        try:
            df = pd.read_csv(file_path)
            # Convert all column names to uppercase and strip spaces
            df.columns = [col.strip().upper() for col in df.columns]
            print(f"Cleaned columns for {stock}: {df.columns.tolist()}")
            
            required_cols = ["DATE", "OPEN", "HIGH", "LOW", "CLOSE", "PROFIT/LOSS"]
            for col in required_cols:
                if col not in df.columns:
                    print(f"Column '{col}' not found in dataset for {stock}.")
            
            last_row = df.iloc[-1]
            ohlc_data = {
                "open": last_row.get("OPEN", "--"),
                "high": last_row.get("HIGH", "--"),
                "low": last_row.get("LOW", "--"),
                "close": last_row.get("CLOSE", "--")
            }
            print(f"Extracted OHLC for {stock}: {ohlc_data}")
            
            # Prepare chart data: use DATE and CLOSE for all records
            chart_df = df[["DATE", "CLOSE"]].dropna()
            chart_df["DATE"] = pd.to_datetime(chart_df["DATE"], errors='coerce').dt.strftime('%Y-%m-%d')
            chart_df = chart_df.sort_values("DATE")
            chart_data = chart_df.to_dict("records")
            print(f"Chart data for {stock} (first 3 records): {chart_data[:3]}")
            
            # Prediction input: last 10 rows of [OPEN, HIGH, LOW, CLOSE]
            features_data = df.tail(10)[["OPEN", "HIGH", "LOW", "CLOSE"]].values.tolist()
            print(f"Features data for {stock} (expected 10x4): {features_data}")
            
            # Recommendation based on PROFIT/LOSS column
            pl_value = str(last_row.get("PROFIT/LOSS", "")).strip().lower()
            if pl_value == "profit":
                recommendation = "Buy"
            elif pl_value == "loss":
                recommendation = "Sell"
            else:
                recommendation = "Hold"
            print(f"Profit/Loss for {stock}: {pl_value} -> Recommendation: {recommendation}")
        except Exception as e:
            print(f"Error processing dataset for {stock}: {e}")
            ohlc_data = {"open": "--", "high": "--", "low": "--", "close": "--"}
            chart_data = []
            features_data = None
            recommendation = "N/A"
    
    return render_template('product.html', stock=stock, ohlc=ohlc_data,
                           chart_data=chart_data, features_data=features_data,
                           recommendation=recommendation)

# Prediction API Route: Use trained model to predict volatility
@app.route('/predict', methods=['POST'])
@login_required
def predict_api():
    try:
        data = request.get_json()
        stock_name = data.get("stock_name")
        features = data.get("features")
        
        if not stock_name or not features:
            return jsonify({"error": "Missing 'stock_name' or 'features'"}), 400
        
        stock_name = stock_name.lower()
        if stock_name not in models or stock_name not in scalers:
            return jsonify({"error": "Model or scaler not available for this stock"}), 400
        
        features = np.array(features)
        if features.shape != (10, 4):
            return jsonify({"error": f"Expected shape (10,4), but got {features.shape}"}), 400
        
        scaler = scalers[stock_name]
        features_scaled = scaler.transform(features)
        features_scaled = features_scaled.reshape(1, 10, 4)
        
        prediction = models[stock_name].predict(features_scaled)
        if prediction.shape != (1, 1):
            return jsonify({"error": f"Unexpected prediction shape: {prediction.shape}"}), 500
        
        predicted_volatility = prediction[0, 0]
        
        return jsonify({"predicted_volatility": float(predicted_volatility)})
    except Exception as e:
        print(f"❌ Prediction error: {e}")
        return jsonify({"error": f"Internal server error: {e}"}), 500

# --------------------------
# Authentication Routes
# --------------------------

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash("Username already exists. Please choose another.")
            return redirect(url_for('signup'))
        new_user = User(username=username, password=password)  # In production, hash passwords!
        db.session.add(new_user)
        db.session.commit()
        flash("Account created. Please log in.")
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            login_user(user)
            return redirect(url_for('home'))
        else:
            flash("Invalid username or password.")
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
