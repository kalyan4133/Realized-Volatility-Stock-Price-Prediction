import os
import numpy as np
import pickle
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.model_selection import train_test_split

# Load preprocessed data
with open("preprocessed_data.pkl", "rb") as f:
    preprocessed_data = pickle.load(f)

# Training parameters
TIME_STEPS = 10  # Number of time steps for LSTM input
EPOCHS = 50
BATCH_SIZE = 16

# Function to create LSTM dataset
def create_sequences(data, time_steps):
    sequences, labels = [], []
    for i in range(len(data) - time_steps):
        sequences.append(data[i:i + time_steps])
        labels.append(data[i + time_steps][-1])  # Predicting the 'Close' price
    return np.array(sequences), np.array(labels)

# Train and save model for each stock
models = {}

for stock, data in preprocessed_data.items():
    print(f"Training model for {stock}...")

    X, y = create_sequences(data, TIME_STEPS)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define LSTM model
    model = Sequential([
        LSTM(50, activation='relu', return_sequences=True, input_shape=(TIME_STEPS, X.shape[2])),
        LSTM(50, activation='relu'),
        Dense(25, activation='relu'),
        Dense(1)  # Predict the Close price
    ])

    model.compile(optimizer='adam', loss='mse')
    model.fit(X_train, y_train, epochs=EPOCHS, batch_size=BATCH_SIZE, validation_data=(X_test, y_test), verbose=1)

    # Save trained model
    model.save(f"{stock}_model.h5")
    models[stock] = model

print("Model training complete. Models saved successfully!")
