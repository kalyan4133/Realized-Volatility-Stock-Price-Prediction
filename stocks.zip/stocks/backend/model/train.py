import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import pickle

# Dataset path
DATASET_PATH = "C:\\Users\\Kalyan Chakravarthi\\Downloads\\stocks\\backend\\static\\datasets"

# Function to preprocess data
def preprocess_data(df):
    # Clean column names
    df.columns = df.columns.str.strip().str.replace('"', '').str.upper()

    # Debugging: Print the cleaned column names
    print("Cleaned Columns:", df.columns.tolist())

    # Ensure required columns exist
    required_cols = ['OPEN', 'HIGH', 'LOW', 'CLOSE']
    missing_cols = [col for col in required_cols if col not in df.columns]

    if missing_cols:
        raise KeyError(f"Missing columns in dataset: {missing_cols}")

    # Scale the selected columns
    scaler = MinMaxScaler()
    df_scaled = scaler.fit_transform(df[required_cols])

    return df_scaled, scaler

# Load all datasets
preprocessed_data = {}
scalers = {}

for file in os.listdir(DATASET_PATH):
    if file.endswith(".csv"):
        file_path = os.path.join(DATASET_PATH, file)
        key = file.replace(".csv", "")  # Use filename as key
        df = pd.read_csv(file_path)

        try:
            preprocessed_data[key], scalers[key] = preprocess_data(df)
            print(f"Processed {file} successfully.")
        except Exception as e:
            print(f"Error processing {file}: {e}")

# Save preprocessed data and scalers
with open("preprocessed_data.pkl", "wb") as f:
    pickle.dump(preprocessed_data, f)

with open("scalers.pkl", "wb") as f:
    pickle.dump(scalers, f)

print("Preprocessing complete. Data saved successfully!")
