import requests
import json
import numpy as np

# Flask API URL
url = "http://127.0.0.1:5000/predict"

# ✅ List of stock names to test
stock_names = [
    "zomato", "wiproooo", "tata", "tata motors",
    "kalamandir", "HDFCLIFE", "ambuja cement"
]

# ✅ Generate 10 time steps of synthetic stock data (Modify as needed)
# Each row should have 4 values (OHLC: Open, High, Low, Close)
sample_features = np.random.uniform(100, 200, (10, 4)).tolist()

# ✅ Loop through each stock and send request
for stock in stock_names:
    data = {
        "stock_name": stock,
        "features": sample_features  # Now (10, 4) shape
    }
    
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, data=json.dumps(data), headers=headers)
    
    print(f"🔹 Stock: {stock}")
    print("Status Code:", response.status_code)
    print("Response:", response.json())
    print("-" * 50)  # Separator for readability
