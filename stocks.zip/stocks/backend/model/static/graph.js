document.addEventListener("DOMContentLoaded", function () {
    // Extracting data for plotting
    const productNames = productData.map(product => product.name);
    const highPrices = productData.map(product => product.high);
    const volumes = productData.map(product => product.volume);

    // Plotting the graph using Plotly
    const trace = {
        x: productNames,
        y: highPrices,
        type: 'bar',
        marker: { color: '#007BFF' },
        name: 'High Prices'
    };

    const layout = {
        title: 'High Prices of Stocks',
        xaxis: { title: 'Products' },
        yaxis: { title: 'High Price' }
    };

    Plotly.newPlot('highPriceGraph', [trace], layout);

    // Populate the price volume table
    const tableBody = document.getElementById("price-volume-data");
    productData.forEach(product => {
        const row = `
            <tr>
                <td>${product.name}</td>
                <td>${product.high}</td>
                <td>${product.volume}</td>
            </tr>`;
        tableBody.innerHTML += row;
    });
});
