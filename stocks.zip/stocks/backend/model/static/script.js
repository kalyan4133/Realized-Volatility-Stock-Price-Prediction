
document.addEventListener('DOMContentLoaded', function () {
    fetch('/get_price_volume_data')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('price-volume-data');

            // Clear existing content
            tbody.innerHTML = '';

            // Populate data dynamically
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.high}</td>
                    <td>${item.volume}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}

document.addEventListener('DOMContentLoaded', function () {
    fetch('/get_graph_data')
        .then(response => response.json())
        .then(data => {
            const graphData = data.graph_data;
            const productData = data.product_data;

            // Populate Table Data
            const tbody = document.getElementById('price-volume-data');
            tbody.innerHTML = '';  // Clear previous data

            productData.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.high}</td>
                    <td>${item.volume}</td>
                `;
                tbody.appendChild(row);
            });

            // Populate Graph Data
            const ctx = document.getElementById('highPriceGraph').getContext('2d');

            const stockNames = graphData.map(item => item.name);
            const highPrices = graphData.map(item => item.high);

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: stockNames,
                    datasets: [{
                        label: 'Stock High Prices',
                        data: highPrices,
                        backgroundColor: 'rgba(75, 192, 192, 0.6)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}

function fetchPrediction(stock) {
    // Use featuresData (should be a 10x4 array)
    fetch('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            stock_name: stock,
            features: featuresData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.predicted_volatility !== undefined) {
            document.getElementById("prediction-result").innerText =
                'Predicted Volatility: ' + data.predicted_volatility.toFixed(2) + '%';
            // Update chart with the historical closing prices
            updateChart(chartData);
        } else {
            document.getElementById("prediction-result").innerText = 'Error in prediction.';
        }
    })
    .catch(error => {
        console.error('Error fetching prediction:', error);
        document.getElementById("prediction-result").innerText = 'Error fetching prediction.';
    });
}

function updateChart(chartData) {
    const ctx = document.getElementById('stockChart').getContext('2d');
    
    // Map DATE to x-axis labels and CLOSE to y-axis data points
    let labels = chartData.map(item => item.DATE);
    let dataPoints = chartData.map(item => parseFloat(item.CLOSE));
    
    console.log("Chart Labels:", labels);
    console.log("Data Points:", dataPoints);
    
    // Render chart using Chart.js
    if (window.stockChart) {
        window.stockChart.destroy();
    }
    
    window.stockChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Closing Price',
                data: dataPoints,
                borderColor: 'blue',
                backgroundColor: 'lightblue',
                fill: false,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'day' },
                    title: { display: true, text: 'Date' }
                },
                y: { title: { display: true, text: 'Price' } }
            }
        }
    });
}
